import os
import base64
import requests
import json

service_url =  os.environ.get('SERVICE_URL')

def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')    
    message = json.loads(pubsub_message)
    employee_id = message["message_id"]
    print(service_url)
    print(employee_id)
    data = requests.get(f'{service_url}/id/{employee_id}')
    d = data.json()
    print(f'Create Dummy ID card... for emp : {d["email"]}')
